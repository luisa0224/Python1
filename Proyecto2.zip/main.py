import csv
from collections import Counter
import statistics
#1. Definición de funciones
def split_list(a_list, other_list):
  """
  Args:
    a_list: list
    other_list: list
  Returns: list split at length of other list
  """
  exp = len(other_list)
  return a_list[:exp]
#Función para separar listas en función de la longitud de otras.

def split_string(s, keep_next=False):
    """
    Args:
      s (str): string
      keep_contiguous (bool): flag to indicate we want to uppercase chars together
    Returns: list of desired parts
    """
    string_length = len(s)
    is_lower_around = (lambda: s[i-1].islower() or 
                       string_length > (i + 1) and s[i + 1].islower())
    is_space_around = (lambda: s[i-1].isspace() or 
                       string_length > (i + 1) and s[i + 1].isspace())  
    start = 0
    parts = []
    for i in range(1, string_length):
      if s[i].isupper() and is_space_around():
        continue
      elif s[i].isupper() and (not keep_next or is_lower_around()):
        parts.append(s[start: i])
        start = i
    parts.append(s[start:])

    return parts
#función que separa textos (str) según mayúsculas pero ignora espacios. La utilizo para separar nombres de países.

#2. Manejo de base
data0=[]

with open ("synergy_logistics_database.csv", "r") as data:
    reader=csv.DictReader(data)
    for line in reader:
        data0.append(line)

for i in data0:
  i["register_id"]=i.pop("\ufeffregister_id")

#Aquí se extraen listas para cada concepto referente. Esto es necesario independientemente de la opción que seleccione el usuario.
exports = []
imports = []
origins = []
destinations = []
routes = []
transport = []
import_transport = []
export_transport = []
export_value = []
import_value = []
origin_import = []
origin_export = []
destination_import = []
destination_export = []

for i in data0:
  route=[None, None]
  transport_total=[None, None]
  for (key, value) in i.items():
    if key == "direction":
      if value == "Exports":
        exports.append(i)
        export_transport.append(i["transport_mode"])
        export_value.append(i["total_value"])
        origin_export.append(i["origin"])
        destination_export.append(i["destination"])
      else:
        imports.append(i)
        import_transport.append(i["transport_mode"])
        import_value.append(i["total_value"])
        origin_import.append(i["origin"])
        destination_import.append(i["destination"])
    if key == "origin":
      origins.append(value)
      route[0] = value
    elif key == "destination":
      destinations.append(value)
      route[1] = value
    if key == "transport_mode":
      transport_total[0] = value
    elif key == "total_value":
      transport_total[1] = value
  routes.append(route)
  transport.append(transport_total)

export_routes=split_list(routes, exports)
import_routes=routes[-len(imports):]

print("Welcome to Synergy Logistics database.\nPlease select an option:\n1. Most common import and export routes.\n2. Modes of transportation.\n3. Most profitable countries.\n")
choice1=int(input("Please select an option: "))

#Menú al usuario
while choice1 == 1 or choice1 == 2 or choice1 == 3:
  #3. Primer punto: Rutas  de  importación  y  exportación más demandadas
  if choice1 == 1:
    count_exports = []
    for i in range(0, len(export_routes)):
      count_exports.append(export_routes[i][0]+export_routes[i][1])

    count_imports = []
    for i in range(0, len(import_routes)):
      count_imports.append(import_routes[i][0]+import_routes[i][1])
  #Se juntan los str de país de origen y destino para crear nombres únicos de rutas, que después se cuentan en forma de diccionario con la función Counter.  
    country_exports=Counter(count_exports)
    country_imports=Counter(count_imports)

  #Número total de rutas de exportación.
    print("\nTotal number of export routes: "+str(len(country_exports)))
    print("\nTen most common export routes: \n")

    country_exports=dict(country_exports)
    country_exports={k: v for k, v in sorted(country_exports.items(), key=lambda item: item[1], reverse=True)}
  #Aquí se usa una función definida al principio para separar el nombre de la ruta de regreso a los nombres de países para poder imprimirlo de forma más elegante. Se realiza lo mismo para las importaciones.
    count=1
    for key in country_exports:
      countries=split_string(key, keep_next=True)
      value=country_exports[key]
      print(str(count)+". Origin: "+str(countries[0])+". Destination: "+str(countries[1])+". Frequency: "+str(value)+".\n")
      if count>9:
        break
      else:
        count+=1

    print("\nTotal number of import routes: "+str(len(country_imports)))

    print("\nTen most common import routes: \n")

    country_imports=dict(country_imports)
    country_imports={k: v for k, v in sorted(country_imports.items(), key=lambda item: item[1], reverse=True)}

    count=1
    for key in country_imports:
      countries=split_string(key, keep_next=True)
      value=country_imports[key]
      print(str(count)+". Origin: "+str(countries[0])+". Destination: "+str(countries[1])+". Frequency: "+str(value)+".\n")
      if count>9:
        break
      else:
        count+=1

    #Justificación: no conviene irse a 10 rutas porque no son regionales. Recomendación: quedarse en región.
  elif choice1 == 2:
    #4. Medio de transporte utilizado. 
    #Se hacen listas separadas de los ingresos dependiendo de la ruta utilizada.
    exp_road = []
    exp_sea = []
    exp_air = []
    exp_rail = []
    sum_road = 0
    sum_sea = 0
    sum_air = 0
    sum_rail = 0

    for i in range(0, len(exports)):
      transport_index=[None, None]
      if export_transport[i]=="Sea":
        transport_index[0]="Sea"
        transport_index[1]=int(export_value[i])
        sum_sea+=int(export_value[i])
        exp_sea.append(transport_index)
      elif export_transport[i]=="Air":
        transport_index[0]="Air"
        transport_index[1]=int(export_value[i])
        exp_air.append(transport_index)
        sum_air+=int(export_value[i])
      elif export_transport[i]=="Rail":
        transport_index[0]="Rail"
        transport_index[1]=int(export_value[i])
        exp_rail.append(transport_index)
        sum_rail+=int(export_value[i])
      elif export_transport[i]=="Road":
        transport_index[0]="Road"
        transport_index[1]=int(export_value[i])
        exp_road.append(transport_index)
        sum_road+=int(export_value[i])

    #Se concentra en una lista para poder ordenar, iterar e imprimir de forma elegante.
    export_costs=[[len(exp_air), "Air", sum_air], [len(exp_sea), "Sea", sum_sea, ], [len(exp_road), "Road", sum_road], [len(exp_rail), "Rail", sum_rail]]

    export_costs.sort(reverse=True)

    print("\nMost common modes of transportation for exports (by total times used): \n")

  #Se imprimen medios de transporte en orden de ingreso por exportación. Se pone abajo el medio restante nada más para comparación visual.
    count=1
    while count<4:
      for i in range(0, 3):
        print(str(count)+". Mode of transportation: "+str(export_costs[i][1])+".\nNumber of times mode of transportation was used: "+str(export_costs[i][0])+".\nTotal earnings: "+str(export_costs[i][2])+"MXN.\n")
        count+=1

    print("\nOther forms of transportation: ")
    print("Mode of transportation: "+str(export_costs[-1][1])+".\nNumber of times mode of transportation was used: "+str(export_costs[-1][0])+".\nTotal earnings: "+str(export_costs[-1][2])+"MXN.\n")

    #Importaciones: se realiza exactamente el mismo procedimiento que para las exportaciones.
    imp_road = []
    imp_sea = []
    imp_air = []
    imp_rail = []
    imp_sum_road = 0
    imp_sum_sea = 0
    imp_sum_air = 0
    imp_sum_rail = 0

    for i in range(0, len(imports)):
      transport_index=[None, None]
      if import_transport[i]=="Sea":
        transport_index[0]="Sea"
        transport_index[1]=int(import_value[i])
        imp_sum_sea+=int(import_value[i])
        imp_sea.append(transport_index)
      elif import_transport[i]=="Air":
        transport_index[0]="Air"
        transport_index[1]=int(import_value[i])
        imp_air.append(transport_index)
        imp_sum_air+=int(export_value[i])
      elif import_transport[i]=="Rail":
        transport_index[0]="Rail"
        transport_index[1]=int(import_value[i])
        imp_rail.append(transport_index)
        imp_sum_rail+=int(import_value[i])
      elif import_transport[i]=="Road":
        transport_index[0]="Road"
        transport_index[1]=int(import_value[i])
        imp_road.append(transport_index)
        imp_sum_road+=int(import_value[i])

    import_costs=[[len(imp_air), "Air", imp_sum_air], [len(imp_sea), "Sea", imp_sum_sea, ], [len(imp_road), "Road", imp_sum_road], [len(imp_rail), "Rail", imp_sum_rail]]

    import_costs.sort(reverse=True)

    print("\nMost common modes of transportation for imports (by total times used): \n")

    count=1
    while count<4:
      for i in range(0, 3):
        print(str(count)+". Mode of transportation: "+str(import_costs[i][1])+".\nNumber of times mode of transportation was used: "+str(import_costs[i][0])+".\nTotal earnings: "+str(import_costs[i][2])+"MXN.\n")
        count+=1

    print("\nOther forms of transportation: ")
    print("Mode of transportation: "+str(import_costs[-1][1])+".\nNumber of times mode of transportation was used: "+str(import_costs[-1][0])+".\nTotal earnings: "+str(import_costs[-1][2])+"MXN.\n")

  ##Aquí se calcula el ingreso neto por medio de transporte (exportación-importación) y se vuelven a ordenar los medios para iterar e imprimir en orden.
    print("Net benefit per mode of transportation:\n")

    import_total=[[len(imp_air), imp_sum_air], [len(imp_sea), imp_sum_sea], [len(imp_road), imp_sum_road], [len(imp_rail), imp_sum_rail]]

    export_total=[[len(exp_air), sum_air], [len(exp_sea), sum_sea], [len(exp_road), sum_road], [len(exp_rail), sum_rail]]

    transports=["Air", "Sea", "Road", "Rail"]

    export_dict=dict(zip(transports, export_total))

    import_dict=dict(zip(transports, import_total))

    total_air=export_dict["Air"][1]-import_dict["Air"][1]
    total_sea=export_dict["Sea"][1]-import_dict["Sea"][1]
    total_road=export_dict["Road"][1]-import_dict["Road"][1]
    total_rail=export_dict["Rail"][1]-import_dict["Rail"][1]

    totals=[total_air, total_sea, total_road, total_rail]

    net_total=list(zip(totals, transports))

    net_total.sort(reverse=True)

    count=0
    for i in range(0, len(net_total)):
      print(str(net_total[count][1])+"route net value: "+str(net_total[count][0])+"MXN.\n")
      count+=1
  elif choice1 == 3:
    #5. Valor total de importaciones y exportaciones. 
    #a. Vamos a asumir que las ganancias son mitad país origen, mitad país destino.
    #b. Vamos a determinar países con ganancia arriba de la percentila 80 de acuerdo a los ingresos de todos los países.
    #Exportaciones: el valor real se calcula con la asunción a. 
    export_value = [int(i) for i in export_value] 
    real_export_value = [i/2 for i in export_value]

    origin_exp_value=list(zip(origin_export, real_export_value))
    destin_exp_value=list(zip(destination_export, real_export_value))
    #Se juntan valores de origen y destino.
    country_exp_value = origin_exp_value+destin_exp_value
    export_sum = sum(export_value)

    exp_sum={}
    for key, value in country_exp_value:
        exp_sum[key] = exp_sum.get(key, 0) + value

    values=exp_sum.values()
    #Se determina los países de interés de acuerdo a la asunción b. Se declaran las quintilas y se clasifica en función de la quintila 20 (queda el 80% de los valores por encima de la quintila).
    limit=statistics.quantiles(values, n=5 ,method='inclusive')

    approved_exp_countries=[]

    for key,value in exp_sum.items():
      if value>=limit[0]:
        approved_exp_countries.append(key)

    #Importaciones: Se realiza lo mismo que para las exportaciones.
    import_value = [int(i) for i in import_value] 
    real_import_value = [i/2 for i in import_value]

    origin_imp_value=list(zip(origin_import, real_import_value))
    destin_imp_value=list(zip(destination_import, real_import_value))

    country_imp_value = origin_imp_value+destin_imp_value
    import_sum = sum(import_value)

    imp_sum={}
    for key, value in country_imp_value:
        imp_sum[key] = imp_sum.get(key, 0) + value

    values_imp=imp_sum.values()

    limit_imp=statistics.quantiles(values_imp, n=5 ,method='inclusive')

    approved_imp_countries=[]

    for key,value in imp_sum.items():
      if value>=limit_imp[0]:
        approved_imp_countries.append(key)

    print("Countries above 80th percentile("+str(limit[0])+"MXN) for exports:\n")
    counter=1
    for i in range(0, len(approved_exp_countries)):
      print(str(counter)+". "+str(approved_exp_countries[i])+".\nTotal export income: "+str(exp_sum[approved_exp_countries[i]])+"MXN,\n")
      counter+=1

    print("Countries above 80th percentile("+str(limit_imp[0])+"MXN) for imports:\n")
    counter=1
    for i in range(0, len(approved_imp_countries)):
      print(str(counter)+". "+str(approved_imp_countries[i])+".\nTotal import income: "+str(imp_sum[approved_imp_countries[i]])+"MXN.\n")
      counter+=1
  #Control de bucle para menú principal. Al seleccionar una opción inválida, se termina el programa.
  choice2=input("Would you like to see anything else? (yes/no)\n")
  if choice2=="yes":
    print("1. Most common import and export routes.\n2. Modes of transportation.\n3. Most profitable countries.\n")
    choice1=int(input("Please select an option: "))
  else:
    choice1=0
    break
print("Have a nice day :)")





